const Discord = require('discord.js');
const ayarlar = require('../ayarlar.json');
// Rise Development
module.exports =  client => { 
client.user.setStatus('idle');
console.log(`Bot Aktif! \nTüm Komutlar Yüklendi\nBu Altyapı Rise Development tarafından yapılmışdır eski ismiyle asuna #2k dandır`)
}