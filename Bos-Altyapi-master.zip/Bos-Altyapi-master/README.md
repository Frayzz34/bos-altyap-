# Bos Altyapı

## Bilgi
- `Cenap` Tarafından Yapılmıştır **Eğer İzinsiz bir şekilde Paylaşılması durumunda En son işlemler Uygulancaktır!**
- **Bu altyapı [`Rise Development`](https://discord.gg/2NQVp5G) Adlı sunucuya Aittir!**
- **Web Site İstiyorsanız Bu Projeye 1k star Gelmesi Lazım! <3**


## Sosyal Medyadan Beni takip edin
[İnstagram](https://www.instagram.com/thekafasizlik.exe/) **|** [Youtube (Sakın Takip etme)](https://www.youtube.com/channel/UC4ub_Yv0e00lEwMNX400HOg?view_as=subscriber) **|** [Twitch](https://www.twitch.tv/cenapwyucw) **|** Github Burası
